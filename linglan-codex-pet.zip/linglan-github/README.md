# Linglan（铃澜）— Codex Pet

冰蓝科技雪狼主题的 Q 版 Codex v2 动画宠物。

## 安装

1. 下载并解压本仓库的发布包。
2. 将 `linglan` 文件夹复制到：
   - macOS / Linux：`~/.codex/pets/linglan`
   - Windows：`%USERPROFILE%\.codex\pets\linglan`
3. 打开 Codex 的 Settings → Pets，选择 Refresh，然后选中 `Linglan（铃澜）`。

## 内容

- `linglan/pet.json` — Codex v2 宠物元数据
- `linglan/spritesheet.webp` — 1536×2288、8×11 动画图集
- `preview/contact-sheet.png` — 全部动作与朝向总览
- `qa/validation-extended.json` — 图集验证结果

## 许可

除非另有书面授权，本项目的角色设定、图像和动画均保留全部权利。允许个人下载和本地使用；不得擅自再发布、商用或移除署名。

## 制作说明

基于用户提供的角色设定图，由 Codex/ChatGPT 协助制作；包含九种标准动作与 16 个顺时针视角。
