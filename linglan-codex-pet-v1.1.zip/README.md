# Linglan（铃澜）— Codex Pet

冰蓝科技雪狼主题的 Q 版 Codex v2 动画宠物。

当前发布版：**v1.1**（动作重绘版）。悬停时保持正面站姿，仅以视线、头部与耳朵的细微变化跟随鼠标，不会切换为侧身或背身形态。

## 安装

1. 下载并解压 `linglan-codex-pet-v1.1.zip`。
2. 将 `linglan` 文件夹复制到：
   - macOS / Linux：`~/.codex/pets/linglan`
   - Windows：`%USERPROFILE%\.codex\pets\linglan`
3. 打开 Codex 的 Settings → Pets，选择 Refresh，然后选中 `Linglan（铃澜）`。

## 内容

- `linglan/pet.json` — Codex v2 宠物元数据
- `linglan/spritesheet.webp` — 1536×2288、8×11 动画图集
- `preview/contact-sheet.png` — 全部动作与朝向总览
- `qa/validation-extended.json` — 图集验证结果

## 许可

除非另有书面授权，本项目的角色设定、图像和动画均保留全部权利。允许个人下载和本地使用；不得擅自再发布、商用或移除署名。

## 制作说明

基于用户提供的角色设定图，由 Codex/ChatGPT 协助制作；包含九种标准动作与 16 个微视线方向。

### v1.1 更新

- 重绘九种标准状态动作，使待机、执行、等待、思考、审阅等状态更易区分。
- 修复跳跃动作的比例不一致问题。
- 重新设计悬停视线：固定正面 Q 版形象，仅做细微的视线、头耳变化。
